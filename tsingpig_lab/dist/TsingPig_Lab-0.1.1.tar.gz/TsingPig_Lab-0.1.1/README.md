# tsingpig_lab
## 1. Introduction
This is a python package for acm-algorithm which is developed by **tsingpig**.

You can connect me by email: 1114196607@qq.com

Thanks for your support!

Version: v0.1.1

## 2. Functions
### 2.1. Data Structure
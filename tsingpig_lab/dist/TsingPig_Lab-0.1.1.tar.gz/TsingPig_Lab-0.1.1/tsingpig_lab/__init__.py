from __future__ import absolute_import
__package_name__ = "TsingPig_Lab"
__version__ = '0.1.1'
__author__ = 'TsingPig'


from ..tsingpig_lab import __version__, __package_name__, __author__

def info():
    print(f'package_name: {__package_name__}')
    print(f'version: {__version__}')
    print(f'author: {__author__}')

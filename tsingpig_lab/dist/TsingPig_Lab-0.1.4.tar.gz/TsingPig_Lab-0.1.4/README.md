# TsingPig - Lab
## 1. Introduction
This is a python package for simple algorithms and data structures which is developed by **tsingpig**.

**Version: v0.1.3**

Author: TsingPig

Repo: [TsingPig / tsingpig_lab · GitLab](https://gitlab.com/tsingpig-code/tsingpig_lab)

You can connect me by email: 1114196607@qq.com

Thanks for your support!



## 2. Functions
### 2.1. DataStructures

#### 2.1.1 Sparse Table (ST)

A data structure ST table (Sparse Table) that supports interval contribution problem queries.

**Usage**

| Method                                               | Description                                                  |
| ---------------------------------------------------- | ------------------------------------------------------------ |
| `__init__(nums: List, opt = lambda a, b: max(a, b))` | Initialize the Sparse Table (ST) data structure with the given list of numbers and an optional comparison function. |
| `qry(L: int, R: int)`                                | Query the opt value within the range [L, R].                 |

**Simple**

``` python
from tsingpig_lab.DataStructures import ST as ST
st = ST([1, 9, 0, 2, 4, 5])
print(st.qry(1, 3))	# 9
```

You can also customize comparison methods by passing function parameters. In default condition, the maximum value will be returned.

```python
from tsingpig_lab.DataStructures import ST as ST
st = ST([1, 9, -99, 2, 4, 5], lambda a, b: min(a, b))
print(st.qry(1, 4)) # -99
```



> Please note that the issue of contribution needs to be met. It means $Opt (x, x)=x$

### 2.2. Algorithms

#### 2.2.1 BaseConverter 

```python 

```

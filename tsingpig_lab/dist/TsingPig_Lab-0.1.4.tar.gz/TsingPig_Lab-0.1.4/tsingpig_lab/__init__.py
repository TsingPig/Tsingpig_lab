from __future__ import absolute_import
__package_name__ = "TsingPig_Lab"
__version__ = '0.1.4'
__author__ = 'TsingPig'

def info():
    print(f'package_name: {__package_name__}')
    print(f'version: {__version__}')
    print(f'author: {__author__}')
'''
pypi-AgEIcHlwaS5vcmcCJDMxZTVjYjEwLTI1ZjgtNDkyYy1hYjk5LTIwODhkMmRhOGU4MQACKlszLCI3NDRkODY1Ni02ODE3LTRiNjEtYTliMi1kZThmOTI0YjQ5ZWEiXQAABiA7fW5wFoRjJYg7bF0l9tnQWja3Lo-ag6U96-XcTmKChw
'''
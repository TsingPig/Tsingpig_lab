from __future__ import absolute_import
__package_name__ = "TsingPig_Lab"
__version__ = '0.1.7'
__author__ = 'TsingPig'

def info():
    print(f'package_name: {__package_name__}')
    print(f'version: {__version__}')
    print(f'author: {__author__}')
